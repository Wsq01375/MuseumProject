





//When the user clicks on Submit, JavaScript then accepts the input that the user entered in the form.   myGuessingGame is my function name.
const theButton=document.getElementById('mySubmit');//This creates a constant for a button called an Id name of'mySubmit'
theButton.addEventListener('click', function(e){
   e.preventDefault();   
    search();}, false);

}
 
    
